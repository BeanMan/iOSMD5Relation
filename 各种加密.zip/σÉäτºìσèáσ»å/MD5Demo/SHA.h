//
//  SHA.h
//  MD5Demo
//
//  Created by bean on 16/2/28.
//  Copyright © 2016年 com.xile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHA : NSObject
+ (NSString*) sha1:(NSString*)sha;
@end
