//
//  MD5.h
//  MD5Demo
//
//  Created by bean on 16/2/28.
//  Copyright © 2016年 com.xile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MD5 : NSObject
+(NSString *) md5: (NSString *) inPutText;
@end
