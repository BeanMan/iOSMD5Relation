//
//  main.m
//  RSA加密
//
//  Created by DYM on 16/7/31.
//  Copyright © 2016年 龙少. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
